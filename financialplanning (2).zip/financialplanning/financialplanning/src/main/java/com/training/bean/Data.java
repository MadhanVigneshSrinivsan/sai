package com.training.bean;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "output from the API ")
	private List<Loan> output;
	
	
	public List<Loan>  getOutput() {
		return output;
	}
	public void setOutput(List<Loan> outputList) {
		this.output = outputList;
	}
	
	
}
