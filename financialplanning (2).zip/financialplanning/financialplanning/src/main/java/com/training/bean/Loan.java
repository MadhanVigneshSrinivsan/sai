package com.training.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel
public class Loan {
	@ApiModelProperty(position=1,required=true,value="LoanType may be Personal, Home and car Loan")
    private String loantype;
	public String getLoantype() {
		return loantype;
	}
	public void setLoantype(String loantype) {
		this.loantype = loantype;
	}
	@ApiModelProperty(position=2,required=true,value="Minimum amount for the particular LoanType")
    private int minAmount;
	public int getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(int minAmount) {
		this.minAmount = minAmount;
	}
	@ApiModelProperty(position=3,required=true,value="Maximum amount for the particular LoanType")
       private int maxAmount;
	public int getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(int maxAmount) {
		this.maxAmount = maxAmount;
	}
	@ApiModelProperty(position=4,required=true,value="Minimum Interest for the particular Loan")

    private int minInterest;
	public int getMinInterest() {
		return minInterest;
	}
	public void setMinInterest(int minInterest) {
		this.minInterest = minInterest;
	}
	
	@ApiModelProperty(position=5,required=true,value="Maximum interest for the particular Loan")
     private int maxInterest;
	public int getMaxInterest() {
		return maxInterest;
	}
	public void setMaxInterest(int maxInterest) {
		this.maxInterest = maxInterest;
	}
	@ApiModelProperty(position=6,required=true,value="Minimum tenture for the particular Loan")

    private int minTenure;
	public int getMinTenure() {
		return minTenure;
	}
	public void setMinTenure(int minTenure) {
		this.minTenure = minTenure;
	}
	
	@ApiModelProperty(position=7,required=true,value="Maximum tenture for the particular Loan")

    private int maxTenure;
	
			
	public int getMaxTenure() {
		return maxTenure;
	}
	public void setMaxTenure(int maxTenure) {
		this.maxTenure = maxTenure;
	}
	}
