package com.training.daoimplementation;

import java.sql.Types;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.training.bean.Loan;
import com.training.dao.LoanJDBC;
import com.training.mapper.LoanMapper;

public class LoanJDBCTemplate implements LoanJDBC {

	Loan loan = null;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public Loan getLoanRange(String loanType) {
		Loan loan = null;
		// loan=
		// jdbcTemplateObject.queryForObject("select * from financialcalculator WHERE loantype = ? ",new
		// Object[] {loanType}, new LoanMapper());

		String SQL = "select * from financialcalculator where loantype = ?";

		loan = jdbcTemplateObject.queryForObject(SQL,new Object[] { loanType }, new LoanMapper());
		return loan;

	}

	public String insertLoanRange(Loan s) {

		String sql = "insert into financialcalculator values('"
                + s.getLoantype() + "'," + s.getMinAmount() + ","
				+ s.getMaxAmount() + "," + s.getMinInterest() + ","
				+ s.getMaxTenure() + "," + s.getMinTenure() + ")";
		jdbcTemplateObject.update(sql);
		return "inserted";
	}

	public Loan deleteLoanRange(String loanType) throws Exception {
		Loan loan = null;
		int rows = 0;
		loan = jdbcTemplateObject.queryForObject(
				"select * from financialcalculator WHERE loantype = ? ",
				new Object[] { loanType }, new LoanMapper());
		rows = jdbcTemplateObject.update(
				"delete from financialcalculator WHERE loantype=?",
				new Object[] { loanType }, new int[] { Types.VARCHAR });

		return (rows == 1 ? loan : null);

	}

	
	 /* public Loan updateLoanRange(int id,Loan s) { Loan loan=null; int rows=0;
	  loan= jdbcTemplateObject.queryForObject(
	  "select * from madhanEmployeeRecord WHERE id = ? ",new Object[] {id}, new
	  LoanMapper()); rows =
	  jdbcTemplateObject.update("update madhanEmployeeRecord set name='"
	  +employee.getName()+"' where id="+id+"",new Object[] {id}, new int[] {
	 Types.NUMERIC }); // rows =
	  jdbcTemplateObject.update("update madhanEmployeeRecord set name='"
	  +s.getName()+"' where id=?",new Object[] {id}, new int[] { Types.NUMERIC
	  });
	  
	  return(rows == 1 ? s : null);
	  
	  
	  
	  }
	 
*/
}
