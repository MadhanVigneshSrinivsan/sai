package com.training.mapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.bean.Goal;




public class GoalMapper implements RowMapper<Goal> {

	public Goal mapRow(ResultSet rs, int rowNum) throws SQLException {
		Goal goal = new Goal();
		goal.setGoal(rs.getString("goal"));
		goal.setTime(rs.getInt("time"));
		goal.setInflationRate(rs.getInt("inflationRate"));
		goal.setRate(rs.getInt("rate"));
		goal.setSavedMoney(rs.getInt("savedMoney"));
		goal.setNeededMoney(rs.getInt("neededMoney"));
		goal.setCorpus(rs.getDouble("corpus"));
		goal.setFinalAmount(rs.getDouble("finalAmount"));
		return goal;
	}

}