

package com.training.dao;

import java.util.ArrayList;

import com.training.bean.Loan;

public interface LoanJDBC {
	public Loan getLoanRange(String loanType) throws Exception;
	public String insertLoanRange(Loan s);
	public Loan deleteLoanRange(String loanType) throws Exception;
	/*public Loan updateLoanRange(int id,Loan s) throws Exception;*/
	

}