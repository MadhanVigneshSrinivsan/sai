package com.training.controller;
import java.util.ArrayList;

import io.swagger.annotations.Api;

import javax.servlet.http.HttpServletRequest;





import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.training.bean.Data;
import com.training.bean.Loan;
import com.training.bean.ErrorDetails;
import com.training.bean.MetaData;
import com.training.bean.Response;
import com.training.daoimplementation.DocumentJDBCTemplate;
import com.training.daoimplementation.LoanJDBCTemplate;

@EnableSwagger2
@RestController
@Api(value = "Loan Documents", description = "Operations on loan documents")

public class DocumentController {
	@Autowired
	DocumentJDBCTemplate documentJDBCTemplate;

	@Autowired
	MetaData metaData;

	@Autowired
	Data data;

	@Autowired
	Response response;

	@Autowired
	ErrorDetails errorDetails;
	@RequestMapping(value = "documents", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Retrieves the details of loan documents", notes = "More notes about this method", response = Response.class)
    @ApiResponses(value = {
                  @ApiResponse(code = 200, message = "Successful retrieval of loan document details", response = Response.class),
                  @ApiResponse(code = 404, message = "Document does not exist", response = Response.class),
                  @ApiResponse(code = 400, message = "Record not found", response = Response.class),
                  @ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
    public ResponseEntity<Response> getAll() {

           ArrayList list = null;
           try {
                  list = documentJDBCTemplate.getAllDetails();
                  System.out.println(list);
                  data.setOutput(list);
                  metaData.setDescription("Retrieves the details of loan documents ");
                  metaData.setResponseId("12345");
                  metaData.setSuccess(true);
                  
                  errorDetails.setCode(null);
                  errorDetails.setDescription(null);
                  response.setData(data);
                  response.setMetaData(metaData);
                  response.setError(errorDetails);
           } catch (Exception e) {
                  metaData.setDescription(" Can't Retrieves the details of loan documents ");
                  metaData.setResponseId("000005");
                  metaData.setSuccess(false);
                  errorDetails.setCode("404");
                  errorDetails.setDescription("UnSuccesfully");
                  data.setOutput(null);
                  response.setData(data);
                  response.setMetaData(metaData);
                  response.setError(errorDetails);
    
                  return new ResponseEntity<Response>(response,HttpStatus.BAD_REQUEST);

           }

           return new ResponseEntity<Response>(response,HttpStatus.OK);
    }

	
	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(
			Exception exception, HttpServletRequest request) {

		errorDetails.setCode("101");
		errorDetails.setDescription("Bad Request");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				errorDetails, HttpStatus.BAD_REQUEST);
		return responseEntity;

	}

}
