package com.training.daoimplementation;

import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.training.bean.Document;
import com.training.dao.DocumentJDBC;
import com.training.mapper.DocumentMapper;

public class DocumentJDBCTemplate implements DocumentJDBC {
	
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	
	public ArrayList<Document> getAllDetails()
    {
		   System.out.println("hello");
           String SQL="select * from financialdocuments";
           @SuppressWarnings("unchecked")
           ArrayList<Document> l=(ArrayList<Document>) jdbcTemplateObject.query(SQL, new DocumentMapper());
           System.out.println(l);
           return l; 
           
               }


}
