package com.training.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.bean.Loan;

public class LoanMapper implements RowMapper<Loan> {

	public Loan mapRow(ResultSet rs, int rowNum) throws SQLException {
		Loan loan = new Loan();
		loan.setLoantype(rs.getString("loantype"));
		loan.setMinAmount(rs.getInt("min_Amount"));
		loan.setMaxAmount(rs.getInt("max_Amount"));
		loan.setMinInterest(rs.getInt("min_Interest"));
		loan.setMaxInterest(rs.getInt("max_Interest"));
		loan.setMinTenure(rs.getInt("min_Tenure"));
		loan.setMaxTenure(rs.getInt("max_Tenure"));
		return loan;
	}

}
