package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.training.bean.Data;
import com.training.bean.Goal;
import com.training.bean.Loan;
import com.training.bean.ErrorDetails;
import com.training.bean.MetaData;
import com.training.bean.Response;
import com.training.daoimplementation.GoalJDBCTemplate;
import com.training.daoimplementation.LoanJDBCTemplate;

@EnableSwagger2
@RestController
@Api(value = "Goal calculator", description = "Operations on goal planning")
public class GoalController {
	@Autowired
	GoalJDBCTemplate goalJDBCTemplate;

	@Autowired
	MetaData metaData;

	@Autowired
	Data data;

	@Autowired
	Response response;

	@Autowired
	ErrorDetails errorDetails;
	
	@RequestMapping(value = "goals", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Retrieves the details of goals", notes = "More notes about this method", response = Response.class)
    @ApiResponses(value = {
                  @ApiResponse(code = 200, message = "Successful retrieval of GoalPlanning details", response = Response.class),
                  @ApiResponse(code = 404, message = "Goal Planning with given goal does not exist", response = Response.class),
                  @ApiResponse(code = 400, message = "Record not found", response = Response.class),
                  @ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
    public ResponseEntity<Response> getAll() {

           ArrayList list = null;
           try {
                  list = goalJDBCTemplate.getAllDetails();
                  data.setOutput(list);
                  metaData.setDescription("Retrieves the details of goal planning ");
                  metaData.setResponseId("12345");
                  metaData.setSuccess(true);
                  
                  errorDetails.setCode(null);
                  errorDetails.setDescription(null);
                  response.setData(data);
                  response.setMetaData(metaData);
                  response.setError(errorDetails);
           } catch (Exception e) {
                  metaData.setDescription(" Can't Retrieves the details of goal planning ");
                  metaData.setResponseId("000005");
                  metaData.setSuccess(false);
                  errorDetails.setCode("404");
                  errorDetails.setDescription("UnSuccesfully");
                  data.setOutput(null);
                  response.setData(data);
                  response.setMetaData(metaData);
                  response.setError(errorDetails);
    
                  return new ResponseEntity<Response>(response,HttpStatus.BAD_REQUEST);

           }

           return new ResponseEntity<Response>(response,HttpStatus.OK);
    }

	@RequestMapping(value = "/goals/{goal}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "creating a goal record", notes = "inserts a goal record", response = Response.class)
	@ResponseStatus(value = HttpStatus.CREATED)
	@ApiResponses(value = {

			@ApiResponse(code = 201, message = "New loan range created", response = Response.class),
			@ApiResponse(code = 404, message = "some thing went wrong", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	public ResponseEntity<Response> insertGoal(
			@ApiParam(name = "goal", value = "goal", required = true) @RequestBody Goal s) {
		List goal = new ArrayList();
		try {
			String z = goalJDBCTemplate.insertGoal(s);
			if (z.equals("inserted")) {
				saveErrorDetails("201", "injected successfully");
				saveMetaData(true, "successfully insertion", "655874");
				response.setData(data);
				response.setError(errorDetails);
				response.setMetaData(metaData);
				return new ResponseEntity<Response>(response,HttpStatus.CREATED);
			} else {
				data.setOutput(null);

				saveErrorDetails("400", "no such LoanType exists");
				saveMetaData(false, "load failed", "545641");
				response.setData(data);
				response.setError(errorDetails);
				response.setMetaData(metaData);
				return new ResponseEntity<Response>(response,
						HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			data.setOutput(null);
			saveErrorDetails("400", "data already exists");
			saveMetaData(false, "data insertion failed", "545641");
			response.setData(data);
			response.setError(errorDetails);
			response.setMetaData(metaData);
			return new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);
		}

	}
	
	private void saveMetaData(boolean success, String description,
			String responseId) {

		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}

	private void saveErrorDetails(String code, String string) {

		errorDetails.setCode(code);
		errorDetails.setDescription(string);
	}

	private void saveResponse(MetaData metaData, Data data,
			ErrorDetails errorDetails) {

		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDetails);

	}

	@ExceptionHandler(TypeMismatchException.class)
	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(
			TypeMismatchException exception, HttpServletRequest request) {

		errorDetails.setCode("100");
		errorDetails.setDescription("Type mismatch exception");
		metaData.setDescription("Goals should be of String");
		metaData.setSuccess(false);
		response.setError(errorDetails);
		response.setMetaData(metaData);
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				response, HttpStatus.BAD_REQUEST);
		return responseEntity;

	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(
			Exception exception, HttpServletRequest request) {

		errorDetails.setCode("101");
		errorDetails.setDescription("Bad Request");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				errorDetails, HttpStatus.BAD_REQUEST);
		return responseEntity;

	}
}
