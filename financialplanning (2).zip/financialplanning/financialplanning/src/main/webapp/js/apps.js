
	
var mainApp = angular.module("myapp", ['ngRoute']);

mainApp.config(function($routeProvider) {
	$routeProvider
		.when('/TemplatePage', {
			templateUrl: 'TemplatePage.html',
					})
		.when('/Calculators', {
			templateUrl: 'CalculatorPage.html',
		
		})
		.otherwise({
			redirectTo: '/TemplatePage'
		});
});
	/*app.controller('mycontroller', function($scope, $http,$location) {*/
		
		
	/*	$scope.Calculator=function()
		{
			$location.path("/CalculatorPage.html");
		};
	      
	*/      
	      /* $scope.CarLoan=function(){
				$location.path("/CarLoan.html");
			

			$http.get("http://localhost:8080/financialplanning/loans/car").then(
					function mySuccess(response) {
						$scope.myWelcome = response.data.data.output;
		 				
						console.log($scope.myWelcome);
						$scope.value3=function(value,value1,value2){
							
							$scope.result =  value*( ( value1* (Math.pow((1+value1),value2)) )/( (Math.pow((1+value1),value2)) -1) );
							alert($scope.result);
						}
				});
	       };
			
			  $scope.PersonalLoan=function(){
					$location.path("/PersonalLoan.html");
				

				$http.get("http://localhost:8080/financialplanning/loans/Personal").then(
						function mySuccess(response) {
							$scope.myWelcome = response.data.data.output;
							
							console.log($scope.myWelcome);
							$scope.value3=function(value,value1,value2){
							if(value1<10){
							
								$scope.result =  value*( ( value1* (Math.pow((1+value1),value2)) )/( (Math.pow((1+value1),value2)) -1) );
								alert($scope.result);
							}
							else{
							}
								
								$scope.result =  value*( ( value1* (Math.pow((1+value1),value2)) )/( (Math.pow((1+value1),value2)) -1) );
								alert($scope.result);
							}
					});
			  };
			  
			  $scope.HomeLoan=function(){
					$location.path("/HomeLoan.html");
				

				$http.get("http://localhost:8080/financialplanning/loans/Home").then(
						function mySuccess(response) {
							$scope.myWelcome = response.data.data.output;
							
							console.log($scope.myWelcome);
							$scope.value3=function(value,value1,value2){
								
								$scope.result =  value*( ( value1* (Math.pow((1+value1),value2)) )/( (Math.pow((1+value1),value2)) -1) );
								alert($scope.result);
							}
					});
			  };
			
	          

			  
			  
			  
			  
			  
			
*/	          
	/*});*/



	/*app.config(function($routeProvider) {
		$routeProvider.when("/Calculators", {
            templateUrl : "CalculatorPage.html",
            controller : 'mycontroller'
           
     }).when('/index', {
            templateUrl : 'TemplatePage.html',
            controller : 'mycontroller'
            
     });
		
		
		
	       $routeProvider.when('/CarLoan.html', {
	              templateUrl : 'CarLoan.html',
	              controller : 'mycontroller'
	       }).when('/index', {
	              templateUrl : 'FirstPage.html',
	              controller : 'mycontroller'
	       });
	       $routeProvider.when('/PersonalLoan.html', {
	              templateUrl : 'PersonalLoan.html',
	              controller : 'mycontroller'
	       }).when('/index', {
	              templateUrl : 'FirstPage.html',
	              controller : 'mycontroller'
	       });
	       
	       $routeProvider.when('/HomeLoan.html', {
	              templateUrl : 'HomeLoan.html',
	              controller : 'mycontroller'
	       }).when('/index', {
	              templateUrl : 'FirstPage.html',
	              controller : 'mycontroller'
	       });
   
	       
	       
	});


*/	

