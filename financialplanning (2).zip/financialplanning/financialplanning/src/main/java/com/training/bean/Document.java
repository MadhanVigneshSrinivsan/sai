package com.training.bean;

import io.swagger.annotations.ApiModelProperty;

public class Document {
	@ApiModelProperty(position=1,required=false,value="Documents needed for getting loan")
	private String document;
	public String getDocument() {
		return document;
	}
	public void setDocument(String document) {
		this.document = document;
	}

}
