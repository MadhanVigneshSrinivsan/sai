

package com.training.daoimplementation;

import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.training.bean.Goal;
import com.training.dao.GoalJDBC;
import com.training.mapper.GoalMapper;

public class GoalJDBCTemplate implements GoalJDBC  {

	Goal goal = null;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public ArrayList<Goal> getAllDetails()
    {
           String SQL="select * from goal_planner";
           @SuppressWarnings("unchecked")
           ArrayList<Goal> l=(ArrayList<Goal>) jdbcTemplateObject.query(SQL, new GoalMapper());
           return l; 
           
               }
	public String insertGoal(Goal s) {
		String sql = "delete from goal_planner where goal='"+s.getGoal()+"'";
		jdbcTemplateObject.update(sql);
		String sql1 = "insert into goal_planner values('"
                + s.getGoal() + "'," + s.getTime() + ","
				+ s.getInflationRate() + "," + s.getRate() + ","
				+ s.getSavedMoney() + "," + s.getNeededMoney() + "," + s.getCorpus() +"," + s.getFinalAmount() +")";
		jdbcTemplateObject.update(sql1);
		return "inserted";
	}
}