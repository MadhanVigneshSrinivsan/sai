package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.training.bean.Data;
import com.training.bean.Loan;
import com.training.bean.ErrorDetails;
import com.training.bean.MetaData;
import com.training.bean.Response;
import com.training.daoimplementation.LoanJDBCTemplate;

@EnableSwagger2
@RestController
@Api(value = "Loan range", description = "Operations on Employee data")
public class LoanController {

	@Autowired
	LoanJDBCTemplate loanJDBCTemplate;

	@Autowired
	MetaData metaData;

	@Autowired
	Data data;

	@Autowired
	Response response;

	@Autowired
	ErrorDetails errorDetails;

	@ApiOperation(value = "retrieves the details of loan details based on the loanType", notes = "Additional notes about this method", response = Response.class)
	@ApiParam(name = "loanType", value = "Loan Type is of type String", required = true)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of loan ranges", response = Response.class),
			// @ApiResponse(code = 201, message
			// ="Successful retrieval of Trainee details", response =
			// Response.class),
			@ApiResponse(code = 404, message = "Loan Details with given loanType does not exist", response = Response.class),
			@ApiResponse(code = 400, message = "No such loan Type record found", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	@RequestMapping(value = "loans/{loanType}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Response> getLoanRange(
			@ApiParam(name = "loanType", value = "loanType", required = true) @PathVariable("loanType") String loanType) {
		ArrayList list = new ArrayList();
		try {
			Loan s = loanJDBCTemplate.getLoanRange(loanType);
			list.add(s);
			data.setOutput(list);
			metaData.setDescription("Retrieving details by loantype ");
			metaData.setSuccess(true);
			errorDetails.setCode("54669");
			errorDetails.setDescription("success");
			response.setData(data);
			response.setMetaData(metaData);
			response.setError(errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		} catch (Exception e) {
			data.setOutput(null);
			saveErrorDetails("400", e.getMessage());
			saveMetaData(false, "load failed", "214854");
			saveResponse(metaData, data, errorDetails);
			return new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);
		}

	}

	@RequestMapping(value = "/loans", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "creating a loan range", notes = "inserts a loan range record", response = Response.class)
	@ResponseStatus(value = HttpStatus.CREATED)
	@ApiResponses(value = {

			@ApiResponse(code = 201, message = "New loan range created", response = Response.class),
			@ApiResponse(code = 404, message = "some thing went wrong", response = Response.class),
			@ApiResponse(code = 400, message = "Bad Request", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	public ResponseEntity<Response> insertLoanRange(
			@ApiParam(name = "loanType", value = "loanType", required = true) @RequestBody Loan s) {
		List loan = new ArrayList();
		try {
			String z = loanJDBCTemplate.insertLoanRange(s);
			if (z.equals("inserted")) {
				saveErrorDetails("201", "injected successfully");
				saveMetaData(true, "successfully insertion", "655874");
				response.setData(data);
				response.setError(errorDetails);
				response.setMetaData(metaData);
				return new ResponseEntity<Response>(response,
						HttpStatus.CREATED);
			} else {
				data.setOutput(null);

				saveErrorDetails("400", "no such LoanType exists");
				saveMetaData(false, "load failed", "545641");
				response.setData(data);
				response.setError(errorDetails);
				response.setMetaData(metaData);
				return new ResponseEntity<Response>(response,
						HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			data.setOutput(null);
			saveErrorDetails("400", "data already exists");
			saveMetaData(false, "data insertion failed", "545641");
			response.setData(data);
			response.setError(errorDetails);
			response.setMetaData(metaData);
			return new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);
		}

	}

	@RequestMapping(value = "loans/{loanType}", method = RequestMethod.DELETE, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "deletes the record", notes = "removes a loan range", response = Response.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful deletion of loan record ", response = Response.class),
			@ApiResponse(code = 404, message = "Record not found", response = Response.class),
			@ApiResponse(code = 400, message = "Loan with loanType does not exist", response = Response.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = Response.class) })
	public ResponseEntity<Response> delete(
			@ApiParam(name = "loanType", value = "Type of the loan applied blah blah blah", required = true) @PathVariable("loanType") String loanType) {
		Loan loan = loanJDBCTemplate.getLoanRange(loanType);

		ArrayList list = new ArrayList();
		try {
			Loan s = loanJDBCTemplate.deleteLoanRange(loanType);
			list.add(s);
			data.setOutput(list);
			metaData.setDescription("deleting the details based on loanType");
			metaData.setResponseId("12876");
			metaData.setSuccess(true);
			response.setData(data);
			response.setError(errorDetails);
			response.setMetaData(metaData);
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		} catch (Exception e) {
			data.setOutput(null);
			saveErrorDetails("400", "LoanType does not exists");
			saveMetaData(false, "Error Occured", "24541");
			response.setData(data);
			response.setError(errorDetails);
			response.setMetaData(metaData);
			return new ResponseEntity<Response>(response,
					HttpStatus.BAD_REQUEST);
		}

	}

	private void saveMetaData(boolean success, String description,
			String responseId) {

		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}

	private void saveErrorDetails(String code, String string) {

		errorDetails.setCode(code);
		errorDetails.setDescription(string);
	}

	private void saveResponse(MetaData metaData, Data data,
			ErrorDetails errorDetails) {

		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDetails);

	}

	@ExceptionHandler(TypeMismatchException.class)
	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(
			TypeMismatchException exception, HttpServletRequest request) {

		errorDetails.setCode("100");
		errorDetails.setDescription("Type mismatch exception");
		metaData.setDescription("LoanType must be of String");
		metaData.setSuccess(false);
		response.setError(errorDetails);
		response.setMetaData(metaData);
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				response, HttpStatus.BAD_REQUEST);
		return responseEntity;

	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(
			Exception exception, HttpServletRequest request) {

		errorDetails.setCode("101");
		errorDetails.setDescription("Bad Request");
		ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
				errorDetails, HttpStatus.BAD_REQUEST);
		return responseEntity;

	}

}
