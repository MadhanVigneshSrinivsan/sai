package com.training.bean;

import io.swagger.annotations.ApiModelProperty;

public class Response {
	@ApiModelProperty(position =1, required = true, value = "Meta Information of the output")
	private MetaData metaData;
	@ApiModelProperty(position = 2, required = true, value = "Output generated from the API")
	private Data data;
	@ApiModelProperty(position = 3, required = true, value = "Error generated during the operation")
	private ErrorDetails Error;
	public MetaData getMetaData() {
		return metaData;
	}
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public ErrorDetails getError() {
		return Error;
	}
	public void setError(ErrorDetails error) {
		Error = error;
	}

}
