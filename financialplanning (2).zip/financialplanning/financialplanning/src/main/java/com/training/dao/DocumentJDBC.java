package com.training.dao;

import java.util.ArrayList;

import com.training.bean.Document;

public interface DocumentJDBC {
	public ArrayList<Document> getAllDetails();
}
