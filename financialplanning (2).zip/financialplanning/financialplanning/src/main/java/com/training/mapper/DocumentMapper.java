package com.training.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.bean.Document;

public class DocumentMapper implements RowMapper<Document> {

	public Document mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		Document document=new Document();
		document.setDocument(rs.getString("documents"));
		return document;
	}

}
