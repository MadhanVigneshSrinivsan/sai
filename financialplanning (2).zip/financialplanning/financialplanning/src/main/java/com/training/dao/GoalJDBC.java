package com.training.dao;

import java.util.ArrayList;

import com.training.bean.Goal;

public interface GoalJDBC {
	public ArrayList<Goal> getAllDetails();
	public String insertGoal(Goal s);
	

}
