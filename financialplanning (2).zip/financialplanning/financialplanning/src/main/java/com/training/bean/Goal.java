package com.training.bean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class Goal {
	
@ApiModelProperty(position=1,required=true,value="Goal of the individual")	
private String goal;

@ApiModelProperty(position=2,required=true,value="Time required to acheive the goal")
private int time;

@ApiModelProperty(position=3,required=true,value="Estimated inflation rate")
private int inflationRate;

@ApiModelProperty(position=4,required=true,value="Rate of return expected")
private int rate;

@ApiModelProperty(position=5,required=true,value="Already saved money by the individual")
private int savedMoney;

@ApiModelProperty(position=6,required=true,value="Additional money required by the individual")
private int neededMoney;

@ApiModelProperty(position=7,required=true,value="Amount to be deposited every month")
private double corpus;

@ApiModelProperty(position=8,required=true,value="Final maturity amount for the goal")
private double finalAmount;

public String getGoal() {
	return goal;
}
public void setGoal(String goal) {
	this.goal = goal;
}
public int getTime() {
	return time;
}
public void setTime(int time) {
	this.time = time;
}
public int getInflationRate() {
	return inflationRate;
}
public void setInflationRate(int inflationRate) {
	this.inflationRate = inflationRate;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public int getSavedMoney() {
	return savedMoney;
}
public void setSavedMoney(int savedMoney) {
	this.savedMoney = savedMoney;
}
public int getNeededMoney() {
	return neededMoney;
}
public void setNeededMoney(int neededMoney) {
	this.neededMoney = neededMoney;
}
public double getCorpus() {
	return corpus;
}
public void setCorpus(double d) {
	this.corpus = d;
}
public double getFinalAmount() {
	return finalAmount;
}
public void setFinalAmount(double finalAmount) {
	this.finalAmount = finalAmount;
}

}
