package com.training.bean;

import io.swagger.annotations.ApiModelProperty;

public class ErrorDetails {
	@ApiModelProperty(position = 1, required = true, value = "code for the error generator ")
private String code;
	@ApiModelProperty(position = 2, required = true, value = "brief description of the error code ")
private String description;
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getDescription() {
	return description;
}
public void setDescription(String e) {
	this.description = e;
}

}
